// ignore-license

#ifdef _WIN32
__declspec(dllexport)
#endif
void foo() {}
