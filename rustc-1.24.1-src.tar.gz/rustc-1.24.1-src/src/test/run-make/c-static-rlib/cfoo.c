// ignore-license
int foo() { return 0; }
