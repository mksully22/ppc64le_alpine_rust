// ignore-license
int should_return_one() { return 0; }
