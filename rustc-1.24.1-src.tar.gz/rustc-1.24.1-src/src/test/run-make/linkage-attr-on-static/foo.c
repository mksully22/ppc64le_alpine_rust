// ignore-license
#include <stdint.h>

extern int32_t BAZ;

int32_t what() {
    return BAZ;
}
